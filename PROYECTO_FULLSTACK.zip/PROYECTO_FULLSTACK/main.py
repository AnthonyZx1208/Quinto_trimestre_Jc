from fastapi import FastAPI, HTTPException


app = FastAPI(
    title="API Académica Relacional en Memoria",
    description="Simulación de base de datos relacional de 5 tablas usando listas de Python",
    version="1.0.0"
)
# ============================================================
# SIMULACIÓN DE TABLAS - ESTRUCTURA RELACIONAL
# ============================================================
# 1. Tabla Roles
roles = [
    {"id": 1, "nombre": "Administrador"},
    {"id": 2, "nombre": "Instructor"},
    {"id": 3, "nombre": "Aprendiz"}
]

# 2. Tabla Usuarios
usuarios = [
    {
        "id": 1,
        "nombre": "Juan",
        "apellido": "Pérez",
        "telefono": "3208529637",
        "edad": 25,
        "rol_id": 3
    },
    {
        "id": 2,
        "nombre": "María",
        "apellido": "Gómez",
        "telefono": "3208529638",
        "edad": 35,
        "rol_id": 2
    }
]

# 3. Tabla Programas
programas = [
    {
        "id": 1,
        "nombre": "Análisis y Desarrollo de Software",
        "codigo": "ADSO-2026"
    },
    {
        "id": 2,
        "nombre": "Diseño y Desarrollo de Multimedia",
        "codigo": "DDM-2026"
    }
]

# 4. Tabla Matrículas
matriculas = [
    {
        "id": 1,
        "usuario_id": 1,
        "programa_id": 1,
        "fecha_matricula": "2026-02-01"
    }
]


# 5. Tabla Asistencias
asistencias = [
    {
        "id": 1,
        "matricula_id": 1,
        "fecha": "2026-02-24",
        "estado": "Asistió"
    }
]

# ============================================================
# ENDPOINT PRINCIPAL
# ============================================================

@app.get("/")
def inicio():
    return {
        "mensaje": "Bienvenido al Sistema Académico de 5 Tablas Relacionadas"
    }

# ============================================================
# ENDPOINTS - ROLES
# ============================================================
@app.get("/roles")
def listar_roles():
    return roles


@app.post("/roles")
def crear_rol(nombre: str):
    nuevo_id = len(roles) + 1

    nuevo_rol = {
        "id": nuevo_id,
        "nombre": nombre
    }

    roles.append(nuevo_rol)

    return nuevo_rol

# ============================================================
# ENDPOINTS - USUARIOS
# ============================================================
@app.get("/usuarios")
def listar_usuarios():
    # Retorna los usuarios incluyendo la información de su rol
    resultado = []

    for usuario in usuarios:
        rol = next(
            (rol for rol in roles if rol["id"] == usuario["rol_id"]),
            None
        )

        resultado.append({
            "id": usuario["id"],
            "nombre": usuario["nombre"],
            "apellido": usuario["apellido"],
            "telefono": usuario["telefono"],
            "edad": usuario["edad"],
            "rol": rol
        })

    return resultado


@app.post("/usuarios")
def crear_usuario(
    nombre: str,
    apellido: str,
    telefono: str,
    edad: int,
    rol_id: int
):
    # Validar integridad referencial
    rol_existente = any(
        rol["id"] == rol_id
        for rol in roles
    )

    if not rol_existente:
        raise HTTPException(
            status_code=400,
            detail="Error de Llave Foránea: El rol_id no existe en la tabla roles."
        )

    nuevo_id = len(usuarios) + 1

    nuevo_usuario = {
        "id": nuevo_id,
        "nombre": nombre,
        "apellido": apellido,
        "telefono": telefono,
        "edad": edad,
        "rol_id": rol_id
    }

    usuarios.append(nuevo_usuario)

    return nuevo_usuario


# ============================================================
# ENDPOINTS - PROGRAMAS
# ============================================================
@app.get("/programas")
def listar_programas():
    return programas


@app.post("/programas")
def crear_programa(nombre: str, codigo: str):
    nuevo_id = len(programas) + 1

    nuevo_programa = {
        "id": nuevo_id,
        "nombre": nombre,
        "codigo": codigo
    }

    programas.append(nuevo_programa)

    return nuevo_programa

# ============================================================
# ENDPOINTS - MATRÍCULAS
# ============================================================
@app.get("/matriculas")
def listar_matriculas():
    resultado = []

    for matricula in matriculas:
        usuario = next(
            (
                usuario
                for usuario in usuarios
                if usuario["id"] == matricula["usuario_id"]
            ),
            None
        )

        programa = next(
            (
                programa
                for programa in programas
                if programa["id"] == matricula["programa_id"]
            ),
            None
        )

        resultado.append({
            "id": matricula["id"],
            "fecha_matricula": matricula["fecha_matricula"],
            "usuario": usuario,
            "programa": programa
        })

    return resultado


@app.post("/matriculas")
def crear_matricula(
    usuario_id: int,
    programa_id: int,
    fecha_matricula: str
):
    # Validar que exista el usuario
    usuario_existente = any(
        usuario["id"] == usuario_id
        for usuario in usuarios
    )

    # Validar que exista el programa
    programa_existente = any(
        programa["id"] == programa_id
        for programa in programas
    )

    if not usuario_existente:
        raise HTTPException(
            status_code=400,
            detail="FK Error: El usuario_id no existe."
        )

    if not programa_existente:
        raise HTTPException(
            status_code=400,
            detail="FK Error: El programa_id no existe."
        )

    nuevo_id = len(matriculas) + 1

    nueva_matricula = {
        "id": nuevo_id,
        "usuario_id": usuario_id,
        "programa_id": programa_id,
        "fecha_matricula": fecha_matricula
    }

    matriculas.append(nueva_matricula)

    return nueva_matricula



@app.get("/asistencias")
def listar_asistencias():
    return asistencias


@app.post("/asistencias")
def registrar_asistencia(
    matricula_id: int,
    fecha: str,
    estado: str
):
    # Validar que exista la matrícula
    matricula_existente = any(
        matricula["id"] == matricula_id
        for matricula in matriculas
    )

    if not matricula_existente:
        raise HTTPException(
            status_code=400,
            detail="FK Error: La matricula_id no existe."
        )

    nuevo_id = len(asistencias) + 1

    nueva_asistencia = {
        "id": nuevo_id,
        "matricula_id": matricula_id,
        "fecha": fecha,
        "estado": estado
    }

    asistencias.append(nueva_asistencia)

    return nueva_asistencia